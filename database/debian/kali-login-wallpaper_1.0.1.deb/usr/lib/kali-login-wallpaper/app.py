#!/usr/bin/env python3
import subprocess
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GLib

APP_ID = "com.bsilent.KaliLoginWallpaper"
HELPER = str(Path(__file__).resolve().parent / "helper.py")
LINK = Path("/usr/share/desktop-base/kali-theme/login/background-blurred")

class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID)
        self.selected = None

    def do_activate(self):
        win = Gtk.ApplicationWindow(application=self)
        win.set_title("Kali Login Wallpaper")
        win.set_default_size(800, 600)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        box.set_margin_top(22); box.set_margin_bottom(22)
        box.set_margin_start(22); box.set_margin_end(22)

        title = Gtk.Label()
        title.set_markup("<span size='x-large' weight='bold'>Kali Login Wallpaper</span>")
        box.append(title)

        self.status = Gtk.Label(label=self.status_text())
        self.status.set_wrap(True)
        box.append(self.status)

        self.preview = Gtk.Picture()
        self.preview.set_can_shrink(True)
        self.preview.set_content_fit(Gtk.ContentFit.CONTAIN)
        self.preview.set_size_request(720, 360)
        box.append(self.preview)

        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        select = Gtk.Button(label="Select Image")
        apply = Gtk.Button(label="Apply Login Background")
        restore = Gtk.Button(label="Restore Original")
        buttons.append(select); buttons.append(apply); buttons.append(restore)
        box.append(buttons)

        hint = Gtk.Label(
            label="PNG • JPG/JPEG • WebP • SVG   |   Automatically cropped to 3840×2160 (16:9)"
        )
        hint.set_wrap(True)
        box.append(hint)

        select.connect("clicked", self.select_image, win)
        apply.connect("clicked", self.apply_image)
        restore.connect("clicked", self.restore_image)

        win.set_child(box)
        win.present()

    def status_text(self):
        if LINK.exists():
            try:
                return f"Active target: {LINK} → {LINK.resolve()}"
            except OSError:
                return f"Active target: {LINK}"
        return "Kali GDM background target not found."

    def select_image(self, _button, win):
        dialog = Gtk.FileDialog(title="Choose Login Background")
        dialog.open(win, None, self.on_file_selected)

    def on_file_selected(self, dialog, result):
        try:
            file = dialog.open_finish(result)
            if not file:
                return
            path = file.get_path()
            if path:
                self.selected = Path(path)
                self.preview.set_filename(path)
                self.status.set_text(f"Selected: {path}")
        except GLib.Error:
            pass

    def run_helper(self, args):
        return subprocess.run(
            ["pkexec", "python3", HELPER] + args,
            text=True,
            capture_output=True
        )

    def apply_image(self, _button):
        if not self.selected:
            self.status.set_text("Select an image first.")
            return
        r = self.run_helper(["apply", str(self.selected)])
        if r.returncode == 0:
            self.status.set_text(
                "✓ Login background applied. The new image will be visible at the next GDM login."
            )
        else:
            self.status.set_text(
                "Apply failed: " + (r.stderr or r.stdout or "Operation cancelled.").strip()
            )

    def restore_image(self, _button):
        r = self.run_helper(["restore"])
        if r.returncode == 0:
            self.status.set_text("✓ Original Kali login background restored.")
        else:
            self.status.set_text(
                "Restore failed: " + (r.stderr or r.stdout or "Operation cancelled.").strip()
            )

App().run()
