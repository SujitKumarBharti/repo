#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageOps

TARGET = Path("/usr/share/backgrounds/kali/login-blurred")
BACKUP_DIR = Path("/var/backups/kali-login-wallpaper")
BACKUP = BACKUP_DIR / "login-blurred.original.jpg"
TMP_DIR = Path("/var/lib/kali-login-wallpaper")
SIZE = (3840, 2160)

def fail(message):
    print(message, file=sys.stderr)
    raise SystemExit(1)

def check():
    if os.geteuid() != 0:
        fail("This helper must run as root.")
    if not TARGET.parent.is_dir():
        fail(f"Kali background directory not found: {TARGET.parent}")

def backup_once():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if not BACKUP.exists() and TARGET.exists():
        shutil.copy2(TARGET, BACKUP)
        os.chown(BACKUP, 0, 0)
        os.chmod(BACKUP, 0o644)

def open_image(path):
    path = Path(path)
    if path.suffix.lower() == ".svg":
        if not shutil.which("rsvg-convert"):
            fail("SVG selected, but rsvg-convert is not installed. Install librsvg2-bin.")
        fd, tmp = tempfile.mkstemp(suffix=".png", dir="/tmp")
        os.close(fd)
        tmp = Path(tmp)
        try:
            r = subprocess.run(
                ["rsvg-convert", "-o", str(tmp), str(path)],
                text=True, capture_output=True
            )
            if r.returncode != 0:
                fail("SVG conversion failed: " + (r.stderr or "unknown error").strip())
            return tmp, True
        except Exception:
            tmp.unlink(missing_ok=True)
            raise
    return path, False

def prepare(source):
    source = Path(source).resolve()
    if not source.is_file():
        fail("Selected image does not exist.")

    TMP_DIR.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".login-", suffix=".jpg", dir=TMP_DIR)
    os.close(fd)
    output = Path(name)

    converted = None
    try:
        actual, converted = open_image(source)
        with Image.open(actual) as img:
            img = ImageOps.exif_transpose(img)
            if img.mode in ("RGBA", "LA"):
                bg = Image.new("RGB", img.size, "black")
                bg.paste(img, mask=img.getchannel("A"))
                img = bg
            else:
                img = img.convert("RGB")
            img = ImageOps.fit(
                img, SIZE,
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5)
            )
            img.save(output, "JPEG", quality=95, optimize=True, progressive=True)
    except SystemExit:
        output.unlink(missing_ok=True)
        raise
    except Exception as e:
        output.unlink(missing_ok=True)
        fail(f"Image conversion failed: {e}")
    finally:
        if converted:
            Path(actual).unlink(missing_ok=True)

    os.chown(output, 0, 0)
    os.chmod(output, 0o644)
    return output

def apply(source):
    check()
    backup_once()
    prepared = prepare(source)
    new = TARGET.with_name(".login-blurred.new")
    try:
        shutil.copy2(prepared, new)
        os.chown(new, 0, 0)
        os.chmod(new, 0o644)
        os.replace(new, TARGET)
    finally:
        prepared.unlink(missing_ok=True)
        new.unlink(missing_ok=True)
    print("Applied successfully.")

def restore():
    check()
    if not BACKUP.exists():
        fail("No original backup exists. Apply an image first.")
    new = TARGET.with_name(".login-blurred.restore")
    shutil.copy2(BACKUP, new)
    os.chown(new, 0, 0)
    os.chmod(new, 0o644)
    os.replace(new, TARGET)
    print("Restored successfully.")

if len(sys.argv) == 3 and sys.argv[1] == "apply":
    apply(sys.argv[2])
elif len(sys.argv) == 2 and sys.argv[1] == "restore":
    restore()
else:
    fail("Usage: helper.py apply <image> | restore")
